v1.2
http://www.hockeystreams.com

hockeystreams.com Roku channel

Working Screens
----------------
Live streams are working
Create an IP Exception from a web browser to view live streams for now
UI is 50% complete
VOD still not working yet
Team names and logos now hosted by hockeystreams.com and pulled on demand by the 
channel

created by brockoli
graphics by dmateiu
